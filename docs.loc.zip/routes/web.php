<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'FundController@index')->name('home');
Route::post('/fund/find', 'FundController@find')->name('fund.find');
Route::post('/fund/edit/{id}', 'FundController@edit')->name('fund.edit');
Route::post('/fund/save', 'FundController@save')->name('fund.save');

Route::prefix('inventory')->group(function() {
    Route::get('/', 'InventoryController@index')->name('inventory.index');
    Route::post('/find', 'InventoryController@find')->name('inventory.find');
    Route::post('/edit/{id}', 'InventoryController@edit')->name('inventory.edit');
    Route::post('/save', 'InventoryController@save')->name('inventory.save');
});

Route::prefix('case')->group(function() {
    Route::get('/', 'CaseController@index')->name('case.index');
    Route::post('/find', 'CaseController@find')->name('case.find');
    Route::post('/edit/{id}', 'CaseController@edit')->name('case.edit');
    Route::post('/save', 'CaseController@save')->name('case.save');
});

Route::prefix('page')->group(function() {
    Route::get('/', 'PageController@index')->name('page.index');
    Route::post('/find', 'PageController@find')->name('page.find');
    Route::post('/edit/{id}', 'PageController@edit')->name('page.edit');
    Route::post('/save', 'PageController@save')->name('page.save');
});

Route::prefix('comments')->group(function() {
    Route::post('/show/{id}/{type}', 'CommentsController@show')->name('comments.find');
    Route::post('/edit/{id}', 'CommentsController@edit')->name('comments.edit');
    Route::post('/save', 'CommentsController@save')->name('comments.save');
});