<div class="filter marTop30 marBot30">
    <div class="form-group">
        <input type="hidden" id="inputPage" class="form-control" placeholder="Начните вводить название документа" />
    </div>

    <div class="input-group">
        <span class="input-group-text">фонд</span>
        <select class="form-select" id="select_fund_page">
            <option value="0">Все фонды</option>
            <?php if($funds->count()): ?>
                <?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fund->id); ?>">
                        <?php echo e($fund->number); ?>

                        <?php echo e($fund->name ? ' - ' . $fund->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <span class="input-group-text">опись</span>
        <select class="form-select" id="select_inventory_page">
            <option value="0">Все описи</option>
            <?php if($inventories->count()): ?>
                <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($inventory->id); ?>">
                        <?php echo e($inventory->number); ?>

                        <?php echo e($inventory->name ? ' - ' . $inventory->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <span class="input-group-text">дело</span>
        <select class="form-select" id="select_case_page">
            <option value="0">Все фонды</option>
            <?php if($cases->count()): ?>
                <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($case->id); ?>">
                        <?php echo e($case->number); ?>

                        <?php echo e($case->name ? ' - ' . $case->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/page/partials/filter.blade.php ENDPATH**/ ?>