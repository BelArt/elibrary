

<?php $__env->startSection('content'); ?>
    <div class="container" id="inventory">
        <?php echo $__env->make('inventory.partials.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="inventoryItems">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/summernote-lite.min.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(asset('js/summernote-lite.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('app.index', ['title' => 'Фонды', 'lnk_inv' => ' active'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/inventory/index.blade.php ENDPATH**/ ?>