<div class="filter marTop30 marBot30">
    <div class="input-group">
        <input type="text" id="inputCase" class="form-control" placeholder="Начните вводить название дела" />
        <span class="input-group-text">фонд</span>
        <select class="form-select" id="select_fund_id_case">
            <option value="0">Все фонды</option>
            <?php if($funds->count()): ?>
                <?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fund->id); ?>">
                        <?php echo e($fund->number); ?>

                        <?php echo e($fund->name ? ' - ' . $fund->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
        <span class="input-group-text">оись</span>
        <select class="form-select" id="select_inventory_case">
            <option value="0">Все описи</option>
            <?php if($inventories->count()): ?>
                <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($inventory->id); ?>">
                        <?php echo e($inventory->number); ?>

                        <?php echo e($inventory->name ? ' - ' . $inventory->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/case/partials/filter.blade.php ENDPATH**/ ?>