<?php if($comments->count()): ?>
    <?php echo $__env->renderEach('comments.parts.item', $comments, 'comment'); ?>
<?php else: ?>
    <div class="alert alert-info">К данной записи пока не оставлено комментариев</div>
<?php endif; ?><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/comments/parts/items.blade.php ENDPATH**/ ?>