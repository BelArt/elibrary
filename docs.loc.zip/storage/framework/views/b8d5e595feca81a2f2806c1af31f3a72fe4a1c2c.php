<div class="filter marTop30 marBot30">
    <div class="input-group">
        <input type="text" id="inputInventory" class="form-control" placeholder="Начните вводить название описи" />
        <span class="input-group-text">в</span>
        <select class="form-select" id="select_fund_id">
            <option value="0">Все фонды</option>
            <?php if($funds->count()): ?>
                <?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fund->id); ?>">
                        <?php echo e($fund->number); ?>

                        <?php echo e($fund->name ? ' - ' . $fund->name : null); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>
</div><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/inventory/partials/filter.blade.php ENDPATH**/ ?>