<?php if($funds->count()): ?>
    <div class="marTop30">
        <div class="fund-item">
            <table class="table table-striped table-bordered">
                <tr>
                    <th>Номер</th>
                    <th>Название</th>
                    <th></th>
                </tr>
                <?php echo $__env->renderEach('fund.partials.item', $funds, 'fund'); ?>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="no-results">Нет данных для отображения</div>
<?php endif; ?><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/fund/partials/items.blade.php ENDPATH**/ ?>