<div class="comment_list--items--item">
    <div class="comment_list--items--item-data">
        <?php echo e(date('d.m.Y в H:i', strtotime($comment->created_at))); ?>

    </div>
    <div class="comment_list--items--item-text">
        <?php echo $comment->comment; ?>

    </div>
</div><?php /**PATH G:\SRV\OSPanel\domains\docs.loc\resources\views/comments/parts/item.blade.php ENDPATH**/ ?>