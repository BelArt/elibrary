<div class="filter marTop30 marBot30">
    <input type="text" id="inputFund" class="form-control" placeholder="Начните вводить название фонда" />
</div>