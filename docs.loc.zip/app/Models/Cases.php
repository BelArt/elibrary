<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cases extends Model
{
    use HasFactory;

    protected $table = 'cases';

    public $timestamps = false;

    /*
    |--------------------------------------------------------------------------
    | RELATIONS
    |--------------------------------------------------------------------------
    */
    public function fund()
    {
        return $this->belongsTo('App\Models\Funds');
    }

    public function inventory()
    {
        return $this->belongsTo('App\Models\Inventory');
    }


    public function setName($name)
    {
        $this->name = $name;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function comments()
    {
        return $this->morphMany(Comments::class, 'morph');
    }
}
